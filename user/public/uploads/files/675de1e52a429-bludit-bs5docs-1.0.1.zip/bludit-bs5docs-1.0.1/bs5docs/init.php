<?php
defined( 'BLUDIT' ) || die( 'That did not work as expected.' );

// Let's not do this, since the BS5Docs Plugin is optional :-)
/*
if ( $themePlugin == false ) {
  exit( 'To ensure proper functionality, the theme requires the BS5Docs plugin. ' .
        'Activate the plugin through the admin panel.' );
}
*/
